#pragma once
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <ctime>

// ================================================================
//  FORWARD DECLARATIONS
// ================================================================
class TransportPass;

// ================================================================
//  CLASS: User  —  Abstract Base Class
//  OOP  : Abstraction (pure virtual), Encapsulation,
//         Operator Overloading (== and <<)
// ================================================================
class User {
protected:
    int         id;
    std::string name;
    std::string password;
    std::string role;   // "student" or "admin"
public:
    User(int id, const std::string& name,
         const std::string& password, const std::string& role);
    virtual ~User();

    int         getId()       const;
    std::string getName()     const;
    std::string getPassword() const;
    std::string getRole()     const;
    void        setPassword(const std::string& p);

    virtual void displayInfo() const = 0;   // Pure virtual — Abstraction

    bool operator==(const User& o) const;
    friend std::ostream& operator<<(std::ostream& os, const User& u);
};

// ================================================================
//  CLASS: Student  —  Derived from User
//  OOP  : Inheritance, Polymorphism,
//         Association with TransportPass (pointer, not owned)
// ================================================================
class Student : public User {
private:
    bool           isRegistered;
    int            assignedRouteId;
    TransportPass* pass;            // Association — NOT owned here
public:
    Student(int id, const std::string& name, const std::string& pwd);
    ~Student() override;

    bool           getIsRegistered()    const;
    int            getAssignedRouteId() const;
    TransportPass* getPass()            const;
    void           setIsRegistered(bool v);
    void           setAssignedRouteId(int r);
    void           setPass(TransportPass* p);

    void displayInfo() const override;   // Polymorphism
};

// ================================================================
//  CLASS: Admin  —  Derived from User
//  OOP  : Inheritance, Polymorphism
// ================================================================
class Admin : public User {
private:
    std::string department;
public:
    Admin(int id, const std::string& name, const std::string& pwd,
          const std::string& dept = "Transport Office");
    ~Admin() override;

    std::string getDepartment() const;
    void        setDepartment(const std::string& d);

    void displayInfo() const override;   // Polymorphism
};

// ================================================================
//  CLASS: Vehicle  —  Abstract Base Class
//  OOP  : Abstraction (pure virtual), Operator Overloading
// ================================================================
class Vehicle {
protected:
    int         vehicleId;
    int         capacity;
    int         occupiedSeats;
    std::string type;    // "Bus" or "Van"
    std::string plate;
public:
    Vehicle(int id, int cap, const std::string& type, const std::string& plate);
    virtual ~Vehicle();

    int         getVehicleId()      const;
    int         getCapacity()       const;
    int         getOccupiedSeats()  const;
    int         getAvailableSeats() const;
    std::string getType()           const;
    std::string getPlate()          const;
    void        setCapacity(int c);
    void        setPlate(const std::string& p);
    void        setOccupiedSeats(int s);
    bool        bookSeat();
    bool        releaseSeat();

    virtual void        displayInfo()    const = 0;  // Pure virtual
    virtual std::string getDescription() const = 0;  // Pure virtual

    bool operator==(const Vehicle& o) const;
    friend std::ostream& operator<<(std::ostream& os, const Vehicle& v);
};

// ================================================================
//  CLASS: Bus  —  Derived from Vehicle
//  OOP  : Inheritance, Polymorphism
// ================================================================
class Bus : public Vehicle {
private:
    bool hasAC;
public:
    Bus(int id, int cap, const std::string& plate, bool ac = true);
    ~Bus() override;

    bool getHasAC()       const;
    void setHasAC(bool v);

    void        displayInfo()    const override;
    std::string getDescription() const override;
};

// ================================================================
//  CLASS: Van  —  Derived from Vehicle
//  OOP  : Inheritance, Polymorphism
// ================================================================
class Van : public Vehicle {
private:
    std::string vanType;
public:
    Van(int id, int cap, const std::string& plate,
        const std::string& vt = "Standard");
    ~Van() override;

    std::string getVanType()              const;
    void        setVanType(const std::string& v);

    void        displayInfo()    const override;
    std::string getDescription() const override;
};

// ================================================================
//  CLASS: Route
//  OOP  : Association (stores vehicleId only, not pointer)
//         Operator Overloading (<< and ==)
// ================================================================
class Route {
private:
    int         routeId;
    std::string startPoint;
    std::string endPoint;
    double      distanceKm;
    double      monthlyFee;
    int         assignedVehicleId;
public:
    Route(int id, const std::string& s, const std::string& e,
          double dist, double fee = 0.0);
    ~Route();

    int         getRouteId()           const;
    std::string getStartPoint()        const;
    std::string getEndPoint()          const;
    double      getDistanceKm()        const;
    double      getMonthlyFee()        const;
    int         getAssignedVehicleId() const;
    void        setMonthlyFee(double f);
    void        setAssignedVehicleId(int v);
    void        displayInfo() const;

    bool operator==(const Route& o) const;
    friend std::ostream& operator<<(std::ostream& os, const Route& r);
};

// ================================================================
//  CLASS: Bill
//  OOP  : Composition — created & owned by TransportPass
//         Operator Overloading — operator+ adds two bill totals
// ================================================================
class Bill {
private:
    int         billId;
    double      baseAmount;
    double      lateFee;
    bool        paid;
    bool        overdue;
    std::string issuedDate;
    std::string dueDate;
    std::string month;
public:
    Bill(int id, double base, const std::string& issued,
         const std::string& due, const std::string& month);

    int         getBillId()     const;
    double      getBaseAmount() const;
    double      getLateFee()    const;
    double      getTotalDue()   const;
    bool        getPaid()       const;
    bool        getOverdue()    const;
    std::string getIssuedDate() const;
    std::string getDueDate()    const;
    std::string getMonth()      const;

    void markPaid();
    void applyLateFee(double fee);
    void checkOverdue(const std::string& today);
    void printInvoice(const std::string& studentName, int routeId) const;

    double operator+(const Bill& o) const;   // Operator Overloading
    friend std::ostream& operator<<(std::ostream& os, const Bill& b);
};

// ================================================================
//  CLASS: TransportPass
//  OOP  : Composition (owns Bill objects — deleted in destructor)
//         Association  (references student by ID, not by pointer)
//         Operator Overloading (<<)
// ================================================================
class TransportPass {
public:
    enum class Status { PENDING, APPROVED, REJECTED, CANCELLED };
private:
    int                passId;
    int                studentId;
    int                routeId;
    Status             status;
    std::string        applicationDate;
    std::vector<Bill*> bills;        // Composition — owns these Bills
    int                nextBillId;
public:
    TransportPass(int passId, int studentId, int routeId,
                  const std::string& date);
    ~TransportPass();   // Deletes all owned Bills (Composition)

    int         getPassId()          const;
    int         getStudentId()       const;
    int         getRouteId()         const;
    Status      getStatus()          const;
    std::string getStatusStr()       const;
    std::string getApplicationDate() const;
    const std::vector<Bill*>& getBills() const;

    void approve();
    void reject();
    void cancel();

    Bill* generateBill(double amount, const std::string& issued,
                       const std::string& due, const std::string& month);
    void  checkAllOverdue(const std::string& today);
    double getTotalRevenue() const;

    void displayInfo()  const;
    void displayBills() const;

    friend std::ostream& operator<<(std::ostream& os, const TransportPass& tp);
};

// ================================================================
//  TEMPLATE CLASS: Report<T>
//  OOP : Template — works for any type T with operator<<
//        Must stay in .h because templates need full definition
//        visible at compile time
// ================================================================
template <typename T>
class Report {
private:
    std::string    title;
    std::vector<T> items;
public:
    explicit Report(const std::string& t) : title(t) {}

    void addItem(const T& item) { items.push_back(item); }
    int  count()          const { return (int)items.size(); }

    void generate() const {
        std::string line(52, '=');
        std::cout << "\n" << line << "\n";
        std::cout << "  REPORT : " << title
                  << "  (" << items.size() << " records)\n";
        std::cout << line << "\n";
        if (items.empty()) {
            std::cout << "  (No data to display)\n";
        } else {
            int i = 1;
            for (const T& item : items)
                std::cout << "  " << std::setw(3) << i++ << ".  " << *item << "\n";
        }
        std::cout << line << "\n";
    }

    // Template member function — accepts any lambda for summary
    template <typename Func>
    void generateWithSummary(Func getValue, const std::string& label) const {
        std::string line(52, '=');
        std::cout << "\n" << line << "\n";
        std::cout << "  REPORT : " << title
                  << "  (" << items.size() << " records)\n";
        std::cout << line << "\n";
        double total = 0;
        if (items.empty()) {
            std::cout << "  (No data)\n";
        } else {
            int i = 1;
            for (const T& item : items) {
                double val = getValue(item);
                std::cout << "  " << std::setw(3) << i++ << ".  " << *item
                          << "  -->  " << std::fixed
                          << std::setprecision(2) << val << "\n";
                total += val;
            }
        }
        std::cout << "  " << std::string(48, '-') << "\n";
        std::cout << "  " << label << " : "
                  << std::fixed << std::setprecision(2) << total << "\n";
        std::cout << line << "\n";
    }
};

// ================================================================
//  CLASS: TransportManager
//  OOP  : Aggregation — owns all Users, Vehicles, Routes, Passes
//         (created with new, deleted in destructor)
// ================================================================
class TransportManager {
private:
    std::vector<User*>          users;
    std::vector<Vehicle*>       vehicles;
    std::vector<Route*>         routes;
    std::vector<TransportPass*> passes;

    int   nextUserId;
    int   nextVehicleId;
    int   nextRouteId;
    int   nextPassId;
    User* currentUser;      // not owned — just a pointer alias

    // Private helpers
    User*          findUserById(int id)         const;
    Student*       findStudentById(int id)      const;
    Vehicle*       findVehicleById(int id)      const;
    Route*         findRouteById(int id)        const;
    TransportPass* findPassByStudentId(int sid) const;
    TransportPass* findPassById(int pid)        const;

    std::string getCurrentDate()  const;
    std::string getCurrentMonth() const;

    static std::vector<std::string> splitLine(const std::string& s, char d);
    static std::string              trimStr(const std::string& s);

public:
    TransportManager();
    ~TransportManager();    // Aggregation cleanup

    // File Handling
    void loadData();
    void saveData();

    // Authentication
    bool  registerUser(const std::string& name, const std::string& pwd,
                       const std::string& role, const std::string& extra = "");
    User* login(const std::string& name, const std::string& pwd);
    void  logout();
    User* getCurrentUser() const;

    // Vehicle Management (Admin)
    void addBus(int cap, const std::string& plate, bool ac);
    void addVan(int cap, const std::string& plate, const std::string& vt);
    void editVehicle(int vid, int newCap, const std::string& newPlate);
    void removeVehicle(int vid);
    void viewAllVehicles() const;

    // Route Management (Admin)
    void addRoute(const std::string& s, const std::string& e,
                  double dist, double fee = 0.0);
    void assignVehicleToRoute(int routeId, int vehicleId);
    void viewAllRoutes() const;

    // Student Operations
    void applyForTransport(int studentId, int routeId);
    void cancelRegistration(int studentId);
    void viewMyRegistration(int studentId) const;
    void viewMyInvoice(int studentId)      const;

    // Application Management (Admin)
    void viewPendingApplications() const;
    void approveApplication(int passId);
    void rejectApplication(int passId);

    // Billing (Admin)
    void generateMonthlyBills();
    void checkOverdueBills();

    // Reports (Admin)
    void generateAllReports() const;
};

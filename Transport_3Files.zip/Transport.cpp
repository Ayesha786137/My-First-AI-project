#include "Transport.h"

// ================================================================
//  User
// ================================================================
User::User(int id, const std::string& name,
           const std::string& password, const std::string& role)
    : id(id), name(name), password(password), role(role) {}

User::~User() {}

int         User::getId()       const { return id; }
std::string User::getName()     const { return name; }
std::string User::getPassword() const { return password; }
std::string User::getRole()     const { return role; }
void        User::setPassword(const std::string& p) { password = p; }

bool User::operator==(const User& o) const { return id == o.id; }

std::ostream& operator<<(std::ostream& os, const User& u) {
    os << "[" << u.role << "] ID=" << u.id << " | Name=" << u.name;
    return os;
}

// ================================================================
//  Student
// ================================================================
Student::Student(int id, const std::string& name, const std::string& pwd)
    : User(id, name, pwd, "student"),
      isRegistered(false), assignedRouteId(-1), pass(nullptr) {}

Student::~Student() {
    pass = nullptr;   // Association: do NOT delete pass here
}

bool           Student::getIsRegistered()    const { return isRegistered; }
int            Student::getAssignedRouteId() const { return assignedRouteId; }
TransportPass* Student::getPass()            const { return pass; }
void           Student::setIsRegistered(bool v)    { isRegistered = v; }
void           Student::setAssignedRouteId(int r)  { assignedRouteId = r; }
void           Student::setPass(TransportPass* p)  { pass = p; }

// OOP: Runtime Polymorphism — overrides pure virtual from User
void Student::displayInfo() const {
    std::cout << "\n  +--------------------------------------+\n";
    std::cout <<   "  |          STUDENT PROFILE             |\n";
    std::cout <<   "  +--------------------------------------+\n";
    std::cout <<   "  | ID        : " << std::setw(25) << std::left << id   << "|\n";
    std::cout <<   "  | Name      : " << std::setw(25) << std::left << name << "|\n";
    std::cout <<   "  | Status    : " << std::setw(25) << std::left
              << (isRegistered ? "Registered" : "Not Registered")            << "|\n";
    std::cout <<   "  | Route ID  : " << std::setw(25) << std::left
              << (assignedRouteId != -1 ? std::to_string(assignedRouteId) : "None") << "|\n";
    std::cout <<   "  +--------------------------------------+\n";
}

// ================================================================
//  Admin
// ================================================================
Admin::Admin(int id, const std::string& name,
             const std::string& pwd, const std::string& dept)
    : User(id, name, pwd, "admin"), department(dept) {}

Admin::~Admin() {}

std::string Admin::getDepartment()               const { return department; }
void        Admin::setDepartment(const std::string& d) { department = d; }

// OOP: Runtime Polymorphism — overrides pure virtual from User
void Admin::displayInfo() const {
    std::cout << "\n  +--------------------------------------+\n";
    std::cout <<   "  |           ADMIN PROFILE              |\n";
    std::cout <<   "  +--------------------------------------+\n";
    std::cout <<   "  | ID         : " << std::setw(24) << std::left << id         << "|\n";
    std::cout <<   "  | Name       : " << std::setw(24) << std::left << name       << "|\n";
    std::cout <<   "  | Department : " << std::setw(24) << std::left << department << "|\n";
    std::cout <<   "  +--------------------------------------+\n";
}

// ================================================================
//  Vehicle
// ================================================================
Vehicle::Vehicle(int id, int cap, const std::string& t, const std::string& pl)
    : vehicleId(id), capacity(cap), occupiedSeats(0), type(t), plate(pl) {}

Vehicle::~Vehicle() {}

int         Vehicle::getVehicleId()      const { return vehicleId; }
int         Vehicle::getCapacity()       const { return capacity; }
int         Vehicle::getOccupiedSeats()  const { return occupiedSeats; }
int         Vehicle::getAvailableSeats() const { return capacity - occupiedSeats; }
std::string Vehicle::getType()           const { return type; }
std::string Vehicle::getPlate()          const { return plate; }
void        Vehicle::setCapacity(int c)        { capacity = c; }
void        Vehicle::setPlate(const std::string& p) { plate = p; }
void        Vehicle::setOccupiedSeats(int s)   { occupiedSeats = s; }

bool Vehicle::bookSeat() {
    if (occupiedSeats < capacity) { ++occupiedSeats; return true; }
    return false;
}
bool Vehicle::releaseSeat() {
    if (occupiedSeats > 0) { --occupiedSeats; return true; }
    return false;
}

bool Vehicle::operator==(const Vehicle& o) const { return vehicleId == o.vehicleId; }

std::ostream& operator<<(std::ostream& os, const Vehicle& v) {
    os << "[" << v.type << " #" << v.vehicleId << "] "
       << v.plate << " | Seats: " << v.occupiedSeats << "/" << v.capacity;
    return os;
}

// ================================================================
//  Bus
// ================================================================
Bus::Bus(int id, int cap, const std::string& pl, bool ac)
    : Vehicle(id, cap, "Bus", pl), hasAC(ac) {}

Bus::~Bus() {}

bool Bus::getHasAC()       const { return hasAC; }
void Bus::setHasAC(bool v)       { hasAC = v; }

// OOP: Runtime Polymorphism
void Bus::displayInfo() const {
    std::cout << "  [BUS #" << vehicleId << "]  " << plate
              << "  |  Capacity : " << capacity
              << "  |  Booked : "   << occupiedSeats
              << "  |  Free : "     << getAvailableSeats()
              << "  |  AC : "       << (hasAC ? "Yes" : "No") << "\n";
}
std::string Bus::getDescription() const {
    return "Bus (Plate:" + plate + " AC:" + (hasAC ? "Y" : "N") + ")";
}

// ================================================================
//  Van
// ================================================================
Van::Van(int id, int cap, const std::string& pl, const std::string& vt)
    : Vehicle(id, cap, "Van", pl), vanType(vt) {}

Van::~Van() {}

std::string Van::getVanType()              const { return vanType; }
void        Van::setVanType(const std::string& v) { vanType = v; }

// OOP: Runtime Polymorphism
void Van::displayInfo() const {
    std::cout << "  [VAN #" << vehicleId << "]  " << plate
              << "  |  Capacity : " << capacity
              << "  |  Booked : "   << occupiedSeats
              << "  |  Free : "     << getAvailableSeats()
              << "  |  Type : "     << vanType << "\n";
}
std::string Van::getDescription() const {
    return "Van/" + vanType + " (Plate:" + plate + ")";
}

// ================================================================
//  Route
// ================================================================
Route::Route(int id, const std::string& s, const std::string& e,
             double dist, double fee)
    : routeId(id), startPoint(s), endPoint(e), distanceKm(dist),
      monthlyFee(fee > 0.0 ? fee : dist * 50.0), assignedVehicleId(-1) {}

Route::~Route() {}

int         Route::getRouteId()           const { return routeId; }
std::string Route::getStartPoint()        const { return startPoint; }
std::string Route::getEndPoint()          const { return endPoint; }
double      Route::getDistanceKm()        const { return distanceKm; }
double      Route::getMonthlyFee()        const { return monthlyFee; }
int         Route::getAssignedVehicleId() const { return assignedVehicleId; }
void        Route::setMonthlyFee(double f)      { monthlyFee = f; }
void        Route::setAssignedVehicleId(int v)  { assignedVehicleId = v; }

void Route::displayInfo() const {
    std::cout << std::fixed << std::setprecision(1);
    std::cout << "  [Route #" << routeId << "]  "
              << startPoint << "  -->  " << endPoint
              << "  |  " << distanceKm << " km"
              << "  |  PKR " << std::setprecision(0) << monthlyFee << "/month"
              << "  |  Vehicle: "
              << (assignedVehicleId != -1
                    ? "ID " + std::to_string(assignedVehicleId)
                    : "None") << "\n";
}

bool Route::operator==(const Route& o) const { return routeId == o.routeId; }

std::ostream& operator<<(std::ostream& os, const Route& r) {
    os << "[Route #" << r.routeId << "]  "
       << r.startPoint << " -> " << r.endPoint
       << "  |  " << r.distanceKm << " km"
       << "  |  PKR " << r.monthlyFee << "/month";
    return os;
}

// ================================================================
//  Bill
// ================================================================
Bill::Bill(int id, double base, const std::string& issued,
           const std::string& due, const std::string& mo)
    : billId(id), baseAmount(base), lateFee(0.0),
      paid(false), overdue(false),
      issuedDate(issued), dueDate(due), month(mo) {}

int         Bill::getBillId()     const { return billId; }
double      Bill::getBaseAmount() const { return baseAmount; }
double      Bill::getLateFee()    const { return lateFee; }
double      Bill::getTotalDue()   const { return baseAmount + lateFee; }
bool        Bill::getPaid()       const { return paid; }
bool        Bill::getOverdue()    const { return overdue; }
std::string Bill::getIssuedDate() const { return issuedDate; }
std::string Bill::getDueDate()    const { return dueDate; }
std::string Bill::getMonth()      const { return month; }

void Bill::markPaid() {
    paid = true;
    std::cout << "  Bill #" << billId << " marked as PAID."
              << "  Total: PKR " << std::fixed << std::setprecision(2)
              << getTotalDue() << "\n";
}

void Bill::applyLateFee(double fee) {
    if (!paid) { lateFee += fee; overdue = true; }
}

void Bill::checkOverdue(const std::string& today) {
    // "YYYY-MM-DD" string comparison works correctly
    if (!paid && today > dueDate) {
        double penalty = baseAmount * 0.10;   // 10% late fee
        applyLateFee(penalty);
        std::cout << "  [OVERDUE] 10% late fee PKR "
                  << std::fixed << std::setprecision(2)
                  << penalty << " added to Bill #" << billId << "\n";
    }
}

void Bill::printInvoice(const std::string& studentName, int routeId) const {
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "\n  ==========================================\n";
    std::cout <<   "           TRANSPORT FEE INVOICE\n";
    std::cout <<   "  ==========================================\n";
    std::cout <<   "  Bill ID    : " << billId       << "\n";
    std::cout <<   "  Student    : " << studentName  << "\n";
    std::cout <<   "  Route ID   : " << routeId      << "\n";
    std::cout <<   "  Month      : " << month        << "\n";
    std::cout <<   "  Issued     : " << issuedDate   << "\n";
    std::cout <<   "  Due Date   : " << dueDate      << "\n";
    std::cout <<   "  ------------------------------------------\n";
    std::cout <<   "  Base Fee   : PKR " << baseAmount   << "\n";
    std::cout <<   "  Late Fee   : PKR " << lateFee      << "\n";
    std::cout <<   "  ------------------------------------------\n";
    std::cout <<   "  TOTAL DUE  : PKR " << getTotalDue() << "\n";
    std::cout <<   "  Status     : "
              << (paid ? "PAID" : (overdue ? "OVERDUE" : "PENDING")) << "\n";
    std::cout <<   "  ==========================================\n";
}

// OOP: Operator Overloading — adds two bills' totals
double Bill::operator+(const Bill& o) const {
    return getTotalDue() + o.getTotalDue();
}

std::ostream& operator<<(std::ostream& os, const Bill& b) {
    os << std::fixed << std::setprecision(2);
    os << "[Bill #" << b.billId << "]  Month=" << b.month
       << "  |  Due=" << b.dueDate
       << "  |  PKR " << b.getTotalDue()
       << "  |  " << (b.paid ? "PAID" : (b.overdue ? "OVERDUE" : "PENDING"));
    return os;
}

// ================================================================
//  TransportPass
// ================================================================
TransportPass::TransportPass(int passId, int studentId,
                             int routeId, const std::string& date)
    : passId(passId), studentId(studentId), routeId(routeId),
      status(Status::PENDING), applicationDate(date), nextBillId(1) {}

// OOP: Composition — destructor deletes all owned Bill objects
TransportPass::~TransportPass() {
    for (Bill* b : bills) delete b;
    bills.clear();
}

int         TransportPass::getPassId()          const { return passId; }
int         TransportPass::getStudentId()       const { return studentId; }
int         TransportPass::getRouteId()         const { return routeId; }
TransportPass::Status TransportPass::getStatus()const { return status; }
std::string TransportPass::getApplicationDate() const { return applicationDate; }
const std::vector<Bill*>& TransportPass::getBills() const { return bills; }

std::string TransportPass::getStatusStr() const {
    switch (status) {
        case Status::PENDING:   return "PENDING";
        case Status::APPROVED:  return "APPROVED";
        case Status::REJECTED:  return "REJECTED";
        case Status::CANCELLED: return "CANCELLED";
        default:                return "UNKNOWN";
    }
}

void TransportPass::approve() {
    status = Status::APPROVED;
    std::cout << "  Pass #" << passId << " APPROVED.\n";
}
void TransportPass::reject() {
    status = Status::REJECTED;
    std::cout << "  Pass #" << passId << " REJECTED.\n";
}
void TransportPass::cancel() {
    status = Status::CANCELLED;
    std::cout << "  Pass #" << passId << " CANCELLED.\n";
}

// OOP: Composition — creates a new Bill owned by this pass
Bill* TransportPass::generateBill(double amount, const std::string& issued,
                                  const std::string& due, const std::string& month) {
    for (Bill* b : bills) {
        if (b->getMonth() == month) {
            std::cout << "  [INFO] Bill for " << month << " already exists.\n";
            return b;
        }
    }
    int id = passId * 1000 + nextBillId++;
    Bill* b = new Bill(id, amount, issued, due, month);
    bills.push_back(b);
    return b;
}

void TransportPass::checkAllOverdue(const std::string& today) {
    for (Bill* b : bills) b->checkOverdue(today);
}

double TransportPass::getTotalRevenue() const {
    double total = 0;
    for (Bill* b : bills)
        if (b->getPaid()) total += b->getTotalDue();
    return total;
}

void TransportPass::displayInfo() const {
    std::cout << "\n  +--------------------------------------+\n";
    std::cout <<   "  |         TRANSPORT PASS               |\n";
    std::cout <<   "  +--------------------------------------+\n";
    std::cout <<   "  | Pass ID     : " << std::setw(22) << std::left << passId           << "|\n";
    std::cout <<   "  | Student ID  : " << std::setw(22) << std::left << studentId        << "|\n";
    std::cout <<   "  | Route ID    : " << std::setw(22) << std::left << routeId          << "|\n";
    std::cout <<   "  | Status      : " << std::setw(22) << std::left << getStatusStr()   << "|\n";
    std::cout <<   "  | Applied On  : " << std::setw(22) << std::left << applicationDate  << "|\n";
    std::cout <<   "  | Total Bills : " << std::setw(22) << std::left << bills.size()     << "|\n";
    std::cout <<   "  +--------------------------------------+\n";
}

void TransportPass::displayBills() const {
    if (bills.empty()) { std::cout << "  No bills generated yet.\n"; return; }
    for (Bill* b : bills) std::cout << "  " << *b << "\n";
}

std::ostream& operator<<(std::ostream& os, const TransportPass& tp) {
    os << "[Pass #" << tp.passId << "]"
       << "  StudentID=" << tp.studentId
       << "  RouteID="   << tp.routeId
       << "  Status="    << tp.getStatusStr();
    return os;
}

// ================================================================
//  TransportManager — Constructor / Destructor
// ================================================================
TransportManager::TransportManager()
    : nextUserId(1), nextVehicleId(1),
      nextRouteId(1), nextPassId(1), currentUser(nullptr) {}

// OOP: Aggregation — destructor deletes everything it owns
TransportManager::~TransportManager() {
    for (User*          u : users)    delete u;
    for (Vehicle*       v : vehicles) delete v;
    for (Route*         r : routes)   delete r;
    for (TransportPass* p : passes)   delete p;
}

// ================================================================
//  Private Helpers
// ================================================================
User* TransportManager::findUserById(int id) const {
    for (User* u : users)
        if (u->getId() == id) return u;
    return nullptr;
}
Student* TransportManager::findStudentById(int id) const {
    for (User* u : users)
        if (u->getId() == id) return dynamic_cast<Student*>(u);
    return nullptr;
}
Vehicle* TransportManager::findVehicleById(int id) const {
    for (Vehicle* v : vehicles)
        if (v->getVehicleId() == id) return v;
    return nullptr;
}
Route* TransportManager::findRouteById(int id) const {
    for (Route* r : routes)
        if (r->getRouteId() == id) return r;
    return nullptr;
}
TransportPass* TransportManager::findPassByStudentId(int sid) const {
    for (TransportPass* p : passes)
        if (p->getStudentId() == sid) return p;
    return nullptr;
}
TransportPass* TransportManager::findPassById(int pid) const {
    for (TransportPass* p : passes)
        if (p->getPassId() == pid) return p;
    return nullptr;
}

std::string TransportManager::getCurrentDate() const {
    time_t now = time(nullptr);
    tm* t = localtime(&now);
    char buf[32];
    snprintf(buf, sizeof(buf), "%04d-%02d-%02d",
             t->tm_year + 1900, t->tm_mon + 1, t->tm_mday);
    return std::string(buf);
}

std::string TransportManager::getCurrentMonth() const {
    return getCurrentDate().substr(0, 7);
}

std::vector<std::string> TransportManager::splitLine(const std::string& s, char d) {
    std::vector<std::string> tokens;
    std::istringstream ss(s);
    std::string tok;
    while (std::getline(ss, tok, d))
        tokens.push_back(tok);
    return tokens;
}

std::string TransportManager::trimStr(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    size_t b = s.find_last_not_of(" \t\r\n");
    return (a == std::string::npos) ? "" : s.substr(a, b - a + 1);
}

// ================================================================
//  FILE HANDLING — Load
// ================================================================
void TransportManager::loadData() {
    std::cout << "  Loading saved data...\n";

    // Load Vehicles
    {
        std::ifstream f("data_vehicles.txt");
        std::string line;
        while (std::getline(f, line)) {
            line = trimStr(line);
            if (line.empty() || line[0] == '#') continue;
            auto t = splitLine(line, '|');
            if (t[0] == "BUS" && t.size() >= 6) {
                int id = std::stoi(t[1]);
                Bus* b = new Bus(id, std::stoi(t[2]), t[4], std::stoi(t[5]) != 0);
                b->setOccupiedSeats(std::stoi(t[3]));
                vehicles.push_back(b);
                if (id >= nextVehicleId) nextVehicleId = id + 1;
            } else if (t[0] == "VAN" && t.size() >= 6) {
                int id = std::stoi(t[1]);
                Van* v = new Van(id, std::stoi(t[2]), t[4], t[5]);
                v->setOccupiedSeats(std::stoi(t[3]));
                vehicles.push_back(v);
                if (id >= nextVehicleId) nextVehicleId = id + 1;
            }
        }
    }

    // Load Routes
    {
        std::ifstream f("data_routes.txt");
        std::string line;
        while (std::getline(f, line)) {
            line = trimStr(line);
            if (line.empty() || line[0] == '#') continue;
            auto t = splitLine(line, '|');
            if (t[0] == "ROUTE" && t.size() >= 7) {
                int id = std::stoi(t[1]);
                Route* r = new Route(id, t[2], t[3],
                                     std::stod(t[4]), std::stod(t[5]));
                r->setAssignedVehicleId(std::stoi(t[6]));
                routes.push_back(r);
                if (id >= nextRouteId) nextRouteId = id + 1;
            }
        }
    }

    // Load Passes and Bills
    {
        std::ifstream f("data_passes.txt");
        std::string line;
        TransportPass* cur = nullptr;
        while (std::getline(f, line)) {
            line = trimStr(line);
            if (line.empty() || line[0] == '#') continue;
            auto t = splitLine(line, '|');
            if (t[0] == "PASS" && t.size() >= 6) {
                int id = std::stoi(t[1]);
                cur = new TransportPass(id, std::stoi(t[2]),
                                        std::stoi(t[3]), t[5]);
                if      (t[4] == "APPROVED")  cur->approve();
                else if (t[4] == "REJECTED")  cur->reject();
                else if (t[4] == "CANCELLED") cur->cancel();
                passes.push_back(cur);
                if (id >= nextPassId) nextPassId = id + 1;
            } else if (t[0] == "BILL" && t.size() >= 10 && cur) {
                double base = std::stod(t[3]);
                double late = std::stod(t[4]);
                bool   paid = std::stoi(t[5]) != 0;
                Bill*  b    = cur->generateBill(base, t[7], t[8], t[9]);
                if (late > 0) b->applyLateFee(late);
                if (paid)     b->markPaid();
            }
        }
    }

    // Load Users (last — so passes are already in memory for linking)
    {
        std::ifstream f("data_users.txt");
        std::string line;
        while (std::getline(f, line)) {
            line = trimStr(line);
            if (line.empty() || line[0] == '#') continue;
            auto t = splitLine(line, '|');
            if (t[0] == "STUDENT" && t.size() >= 7) {
                int id = std::stoi(t[1]);
                Student* s = new Student(id, t[2], t[3]);
                s->setIsRegistered(std::stoi(t[4]) != 0);
                s->setAssignedRouteId(std::stoi(t[5]));
                // Restore Association: link pass pointer
                TransportPass* p = findPassByStudentId(id);
                if (p) s->setPass(p);
                users.push_back(s);
                if (id >= nextUserId) nextUserId = id + 1;
            } else if (t[0] == "ADMIN" && t.size() >= 5) {
                int id = std::stoi(t[1]);
                Admin* a = new Admin(id, t[2], t[3], t[4]);
                users.push_back(a);
                if (id >= nextUserId) nextUserId = id + 1;
            }
        }
    }

    std::cout << "  Loaded: "
              << users.size()    << " users  |  "
              << vehicles.size() << " vehicles  |  "
              << routes.size()   << " routes  |  "
              << passes.size()   << " passes.\n";
}

// ================================================================
//  FILE HANDLING — Save
// ================================================================
void TransportManager::saveData() {
    std::cout << "  Saving data...\n";

    // Save Vehicles
    {
        std::ofstream f("data_vehicles.txt");
        f << "# Vehicles\n";
        for (Vehicle* v : vehicles) {
            if (v->getType() == "Bus") {
                Bus* b = dynamic_cast<Bus*>(v);
                f << "BUS|"  << v->getVehicleId()   << "|"
                  << v->getCapacity()               << "|"
                  << v->getOccupiedSeats()          << "|"
                  << v->getPlate()                  << "|"
                  << (b->getHasAC() ? 1 : 0)        << "\n";
            } else {
                Van* va = dynamic_cast<Van*>(v);
                f << "VAN|"  << v->getVehicleId()   << "|"
                  << v->getCapacity()               << "|"
                  << v->getOccupiedSeats()          << "|"
                  << v->getPlate()                  << "|"
                  << va->getVanType()               << "\n";
            }
        }
    }

    // Save Routes
    {
        std::ofstream f("data_routes.txt");
        f << "# Routes\n";
        for (Route* r : routes)
            f << "ROUTE|" << r->getRouteId()          << "|"
              << r->getStartPoint()                   << "|"
              << r->getEndPoint()                     << "|"
              << r->getDistanceKm()                   << "|"
              << r->getMonthlyFee()                   << "|"
              << r->getAssignedVehicleId()            << "\n";
    }

    // Save Passes and Bills
    {
        std::ofstream f("data_passes.txt");
        f << "# Passes and Bills\n";
        for (TransportPass* p : passes) {
            f << "PASS|" << p->getPassId()    << "|"
              << p->getStudentId()            << "|"
              << p->getRouteId()              << "|"
              << p->getStatusStr()            << "|"
              << p->getApplicationDate()      << "\n";
            for (Bill* b : p->getBills())
                f << "BILL|" << b->getBillId()      << "|"
                  << p->getPassId()                 << "|"
                  << b->getBaseAmount()             << "|"
                  << b->getLateFee()                << "|"
                  << (b->getPaid()    ? 1 : 0)      << "|"
                  << (b->getOverdue() ? 1 : 0)      << "|"
                  << b->getIssuedDate()             << "|"
                  << b->getDueDate()                << "|"
                  << b->getMonth()                  << "\n";
        }
    }

    // Save Users
    {
        std::ofstream f("data_users.txt");
        f << "# Users\n";
        for (User* u : users) {
            if (u->getRole() == "student") {
                Student* s = dynamic_cast<Student*>(u);
                f << "STUDENT|" << u->getId()              << "|"
                  << u->getName()                          << "|"
                  << u->getPassword()                      << "|"
                  << (s->getIsRegistered() ? 1 : 0)        << "|"
                  << s->getAssignedRouteId()               << "|"
                  << (s->getPass() ? s->getPass()->getPassId() : -1) << "\n";
            } else {
                Admin* a = dynamic_cast<Admin*>(u);
                f << "ADMIN|" << u->getId()   << "|"
                  << u->getName()             << "|"
                  << u->getPassword()         << "|"
                  << a->getDepartment()       << "\n";
            }
        }
    }

    std::cout << "  Data saved successfully.\n";
}

// ================================================================
//  AUTHENTICATION
// ================================================================
bool TransportManager::registerUser(const std::string& name,
                                    const std::string& pwd,
                                    const std::string& role,
                                    const std::string& extra) {
    for (User* u : users) {
        if (u->getName() == name) {
            std::cout << "  [ERROR] Username '" << name << "' already taken.\n";
            return false;
        }
    }
    User* u = nullptr;
    if (role == "student")
        u = new Student(nextUserId++, name, pwd);
    else if (role == "admin")
        u = new Admin(nextUserId++, name, pwd,
                      extra.empty() ? "Transport Office" : extra);
    else {
        std::cout << "  [ERROR] Invalid role.\n";
        return false;
    }
    users.push_back(u);
    std::cout << "  Registered! ID=" << u->getId() << " | Role=" << role << "\n";
    return true;
}

User* TransportManager::login(const std::string& name, const std::string& pwd) {
    for (User* u : users) {
        if (u->getName() == name && u->getPassword() == pwd) {
            currentUser = u;
            std::cout << "  Login successful! Welcome, " << name << "!\n";
            return u;
        }
    }
    std::cout << "  [ERROR] Incorrect username or password.\n";
    return nullptr;
}

void  TransportManager::logout() {
    if (currentUser)
        std::cout << "  Goodbye, " << currentUser->getName() << "!\n";
    currentUser = nullptr;
}

User* TransportManager::getCurrentUser() const { return currentUser; }

// ================================================================
//  VEHICLE MANAGEMENT
// ================================================================
void TransportManager::addBus(int cap, const std::string& plate, bool ac) {
    vehicles.push_back(new Bus(nextVehicleId++, cap, plate, ac));
    std::cout << "  Bus added! ID=" << vehicles.back()->getVehicleId() << "\n";
}

void TransportManager::addVan(int cap, const std::string& plate, const std::string& vt) {
    vehicles.push_back(new Van(nextVehicleId++, cap, plate, vt));
    std::cout << "  Van added! ID=" << vehicles.back()->getVehicleId() << "\n";
}

void TransportManager::editVehicle(int vid, int newCap, const std::string& newPlate) {
    Vehicle* v = findVehicleById(vid);
    if (!v) { std::cout << "  [ERROR] Vehicle not found.\n"; return; }
    if (newCap > 0)        v->setCapacity(newCap);
    if (!newPlate.empty()) v->setPlate(newPlate);
    std::cout << "  Vehicle #" << vid << " updated.\n";
}

void TransportManager::removeVehicle(int vid) {
    for (Route* r : routes) {
        if (r->getAssignedVehicleId() == vid) {
            std::cout << "  [ERROR] Vehicle assigned to Route #"
                      << r->getRouteId() << ". Unassign first.\n";
            return;
        }
    }
    auto it = std::find_if(vehicles.begin(), vehicles.end(),
                  [vid](Vehicle* v){ return v->getVehicleId() == vid; });
    if (it == vehicles.end()) { std::cout << "  [ERROR] Vehicle not found.\n"; return; }
    delete *it;
    vehicles.erase(it);
    std::cout << "  Vehicle #" << vid << " removed.\n";
}

void TransportManager::viewAllVehicles() const {
    if (vehicles.empty()) { std::cout << "  No vehicles registered.\n"; return; }
    std::cout << "\n  --- Vehicles (" << vehicles.size() << ") ---\n";
    for (Vehicle* v : vehicles)
        v->displayInfo();   // OOP: Runtime Polymorphism (Bus or Van)
}

// ================================================================
//  ROUTE MANAGEMENT
// ================================================================
void TransportManager::addRoute(const std::string& s, const std::string& e,
                                double dist, double fee) {
    routes.push_back(new Route(nextRouteId++, s, e, dist, fee));
    std::cout << "  Route added! ID=" << routes.back()->getRouteId() << "\n";
}

void TransportManager::assignVehicleToRoute(int routeId, int vehicleId) {
    Route*   r = findRouteById(routeId);
    Vehicle* v = findVehicleById(vehicleId);
    if (!r) { std::cout << "  [ERROR] Route not found.\n";   return; }
    if (!v) { std::cout << "  [ERROR] Vehicle not found.\n"; return; }
    r->setAssignedVehicleId(vehicleId);
    std::cout << "  Vehicle #" << vehicleId
              << " assigned to Route #" << routeId << "\n";
}

void TransportManager::viewAllRoutes() const {
    if (routes.empty()) { std::cout << "  No routes defined.\n"; return; }
    std::cout << "\n  --- Routes (" << routes.size() << ") ---\n";
    for (Route* r : routes) {
        r->displayInfo();
        if (r->getAssignedVehicleId() != -1) {
            Vehicle* v = findVehicleById(r->getAssignedVehicleId());
            if (v) std::cout << "    Available seats: "
                             << v->getAvailableSeats()
                             << "/" << v->getCapacity() << "\n";
        }
    }
}

// ================================================================
//  STUDENT OPERATIONS
// ================================================================
void TransportManager::applyForTransport(int studentId, int routeId) {
    Student* s = findStudentById(studentId);
    if (!s) { std::cout << "  [ERROR] Student not found.\n"; return; }

    if (s->getIsRegistered()) {
        std::cout << "  [ERROR] Already registered for a route.\n"; return;
    }

    Route* r = findRouteById(routeId);
    if (!r) { std::cout << "  [ERROR] Route not found.\n"; return; }

    // Capacity check (no overbooking)
    if (r->getAssignedVehicleId() != -1) {
        Vehicle* v = findVehicleById(r->getAssignedVehicleId());
        if (v && v->getAvailableSeats() <= 0) {
            std::cout << "  [ERROR] No seats available on this route.\n"; return;
        }
    }

    // One active application per student
    TransportPass* ex = findPassByStudentId(studentId);
    if (ex && (ex->getStatus() == TransportPass::Status::PENDING ||
               ex->getStatus() == TransportPass::Status::APPROVED)) {
        std::cout << "  [ERROR] You already have an active application.\n"; return;
    }

    // Dynamic allocation — new pass created here
    TransportPass* p = new TransportPass(nextPassId++, studentId,
                                         routeId, getCurrentDate());
    passes.push_back(p);
    s->setPass(p);
    s->setAssignedRouteId(routeId);
    std::cout << "  Application submitted!"
              << "  Pass ID=" << p->getPassId()
              << "  |  Status: PENDING\n";
}

void TransportManager::cancelRegistration(int studentId) {
    Student* s = findStudentById(studentId);
    if (!s) { std::cout << "  [ERROR] Student not found.\n"; return; }

    TransportPass* p = findPassByStudentId(studentId);
    if (!p || p->getStatus() == TransportPass::Status::CANCELLED) {
        std::cout << "  [ERROR] No active registration found.\n"; return;
    }

    // Release seat if was approved
    if (p->getStatus() == TransportPass::Status::APPROVED) {
        Route* r = findRouteById(p->getRouteId());
        if (r && r->getAssignedVehicleId() != -1) {
            Vehicle* v = findVehicleById(r->getAssignedVehicleId());
            if (v) v->releaseSeat();
        }
    }
    p->cancel();
    s->setIsRegistered(false);
    s->setAssignedRouteId(-1);
    s->setPass(nullptr);
}

void TransportManager::viewMyRegistration(int studentId) const {
    Student* s = findStudentById(studentId);
    if (!s) { std::cout << "  [ERROR] Not found.\n"; return; }
    s->displayInfo();
    TransportPass* p = findPassByStudentId(studentId);
    if (!p) { std::cout << "  No transport application found.\n"; return; }
    p->displayInfo();
    if (p->getStatus() == TransportPass::Status::APPROVED) {
        std::cout << "\n  --- Bills ---\n";
        p->displayBills();
    }
}

void TransportManager::viewMyInvoice(int studentId) const {
    Student*       s = findStudentById(studentId);
    TransportPass* p = findPassByStudentId(studentId);
    if (!s || !p || p->getBills().empty()) {
        std::cout << "  No bills found.\n"; return;
    }
    for (Bill* b : p->getBills())
        b->printInvoice(s->getName(), p->getRouteId());
}

// ================================================================
//  APPLICATION MANAGEMENT
// ================================================================
void TransportManager::viewPendingApplications() const {
    bool found = false;
    std::cout << "\n  --- Pending Applications ---\n";
    for (TransportPass* p : passes) {
        if (p->getStatus() == TransportPass::Status::PENDING) {
            std::cout << "  " << *p << "\n";
            Student* s = findStudentById(p->getStudentId());
            if (s) std::cout << "    Student  : " << s->getName() << "\n";
            Route*   r = findRouteById(p->getRouteId());
            if (r) std::cout << "    Route    : " << *r << "\n";
            found = true;
        }
    }
    if (!found) std::cout << "  No pending applications.\n";
}

void TransportManager::approveApplication(int passId) {
    TransportPass* p = findPassById(passId);
    if (!p || p->getStatus() != TransportPass::Status::PENDING) {
        std::cout << "  [ERROR] Pass not found or not PENDING.\n"; return;
    }
    Route* r = findRouteById(p->getRouteId());
    if (r && r->getAssignedVehicleId() != -1) {
        Vehicle* v = findVehicleById(r->getAssignedVehicleId());
        if (v && v->getAvailableSeats() <= 0) {
            std::cout << "  [ERROR] No seats left. Cannot approve.\n"; return;
        }
        if (v) v->bookSeat();
    }
    p->approve();
    Student* s = findStudentById(p->getStudentId());
    if (s) s->setIsRegistered(true);
}

void TransportManager::rejectApplication(int passId) {
    TransportPass* p = findPassById(passId);
    if (!p || p->getStatus() != TransportPass::Status::PENDING) {
        std::cout << "  [ERROR] Pass not found or not PENDING.\n"; return;
    }
    p->reject();
    Student* s = findStudentById(p->getStudentId());
    if (s) {
        s->setIsRegistered(false);
        s->setAssignedRouteId(-1);
        s->setPass(nullptr);
    }
}

// ================================================================
//  BILLING
// ================================================================
void TransportManager::generateMonthlyBills() {
    std::string month  = getCurrentMonth();
    std::string issued = getCurrentDate();

    int year = std::stoi(month.substr(0, 4));
    int mon  = std::stoi(month.substr(5, 2));
    if (++mon > 12) { mon = 1; year++; }
    char due[32];
    snprintf(due, sizeof(due), "%04d-%02d-15", year, mon);

    int count = 0;
    for (TransportPass* p : passes) {
        if (p->getStatus() == TransportPass::Status::APPROVED) {
            Route*  r   = findRouteById(p->getRouteId());
            double  fee = r ? r->getMonthlyFee() : 2500.0;
            p->generateBill(fee, issued, std::string(due), month);
            count++;
        }
    }
    std::cout << "  Bills generated for " << count
              << " students  |  Month: " << month << "\n";
}

void TransportManager::checkOverdueBills() {
    std::string today = getCurrentDate();
    for (TransportPass* p : passes)
        p->checkAllOverdue(today);
    std::cout << "  Overdue check complete.\n";
}

// ================================================================
//  REPORTS — uses template class Report<T>
// ================================================================
void TransportManager::generateAllReports() const {

    // Template instantiation with Student*
    Report<Student*> rStudents("Registered Students");
    for (User* u : users) {
        Student* s = dynamic_cast<Student*>(u);
        if (s && s->getIsRegistered()) rStudents.addItem(s);
    }
    rStudents.generate();

    // Template instantiation with Vehicle* + summary lambda
    Report<Vehicle*> rVehicles("Vehicle Occupancy");
    for (Vehicle* v : vehicles) rVehicles.addItem(v);
    rVehicles.generateWithSummary(
        [](Vehicle* v){ return (double)v->getOccupiedSeats(); },
        "Total Booked Seats");

    // Template instantiation with Route*
    Report<Route*> rRoutes("All Routes");
    for (Route* r : routes) rRoutes.addItem(r);
    rRoutes.generate();

    // Revenue Summary
    std::string line(52, '=');
    std::cout << "\n" << line << "\n";
    std::cout << "  REPORT : Revenue Summary\n" << line << "\n";
    double total = 0;
    for (TransportPass* p : passes) {
        if (p->getStatus() == TransportPass::Status::APPROVED) {
            double   rev = p->getTotalRevenue();
            Student* s   = findStudentById(p->getStudentId());
            std::cout << "  Student : " << std::setw(15) << std::left
                      << (s ? s->getName() : "Unknown")
                      << "  |  Paid: PKR "
                      << std::fixed << std::setprecision(2) << rev << "\n";
            total += rev;
        }
    }
    std::cout << "  " << std::string(48, '-') << "\n";
    std::cout << "  Total Collected : PKR "
              << std::fixed << std::setprecision(2) << total << "\n";
    std::cout << line << "\n";
}

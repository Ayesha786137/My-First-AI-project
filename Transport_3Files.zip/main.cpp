#include "Transport.h"
#include <limits>
static void clearInput() { // INPUT HELPERS
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}
static void pause() {
    std::cout << "\n  Press ENTER to continue...";
    std::cin.get();
}
static void showHeader(const std::string& title) {
    std::cout << "\n  +==========================================+\n";
    std::cout <<   "  |  " << std::left << std::setw(40) << title << "|\n";
    std::cout <<   "  +==========================================+\n\n";
}
static int getInt(const std::string& prompt) {
    int val;
    std::cout << prompt;
    while (!(std::cin >> val)) {
        std::cin.clear();
        clearInput();
        std::cout << "  Enter a number: ";
    }
    clearInput();
    return val;
}
static std::string getStr(const std::string& prompt) {
    std::string s;
    std::cout << prompt;
    std::getline(std::cin, s);
    return s;
}
void studentMenu(TransportManager& mgr, Student* student) { // STUDENT MENUE
    int choice;
    do {
        showHeader("STUDENT MENU  [ " + student->getName() + " ]");
        std::cout << "  1. View All Routes\n"
                  << "  2. Apply for Transport\n"
                  << "  3. View My Registration & Pass\n"
                  << "  4. View My Invoice / Bill\n"
                  << "  5. Cancel Registration\n"
                  << "  0. Logout\n";
        choice = getInt("\n  Enter choice: ");

        switch (choice) {
            case 1:
                mgr.viewAllRoutes();
                pause();
                break;

            case 2:
                mgr.viewAllRoutes();
                mgr.applyForTransport(
                    student->getId(),
                    getInt("  Enter Route ID: ")
                );
                pause();
                break;

            case 3:
                mgr.viewMyRegistration(student->getId());
                pause();
                break;

            case 4:
                mgr.viewMyInvoice(student->getId());
                pause();
                break;

            case 5:
                mgr.cancelRegistration(student->getId());
                pause();
                break;

            case 0:
                mgr.logout();
                break;

            default:
                std::cout << "  [!] Invalid option.\n";
        }
    } while (choice != 0);
}
void adminMenu(TransportManager& mgr) { // ADMIN MENU
    int choice;
    do {
        showHeader("ADMIN MENU");
        std::cout << "  -- Vehicles --\n"
                  << "   1. Add Bus\n"
                  << "   2. Add Van\n"
                  << "   3. Edit Vehicle\n"
                  << "   4. Remove Vehicle\n"
                  << "   5. View All Vehicles\n"
                  << "  -- Routes --\n"
                  << "   6. Add Route\n"
                  << "   7. Assign Vehicle to Route\n"
                  << "   8. View All Routes\n"
                  << "  -- Applications --\n"
                  << "   9. View Pending Applications\n"
                  << "  10. Approve Application\n"
                  << "  11. Reject Application\n"
                  << "  -- Billing --\n"
                  << "  12. Generate Monthly Bills\n"
                  << "  13. Check Overdue Bills\n"
                  << "  -- Reports --\n"
                  << "  14. Generate All Reports\n"
                  << "  -- System --\n"
                  << "  15. Save Data\n"
                  << "   0. Logout\n";
        choice = getInt("\n  Enter choice: ");

        switch (choice) {

            case 1: {
                int  cap   = getInt("  Capacity       : ");
                auto plate = getStr("  License Plate  : ");
                int  ac    = getInt("  Has AC (1=Yes 0=No): ");
                mgr.addBus(cap, plate, ac != 0);
                pause();
                break;
            }

            case 2: {
                int  cap   = getInt("  Capacity       : ");
                auto plate = getStr("  License Plate  : ");
                auto vtype = getStr("  Van Type (Coaster/Hiace/Standard): ");
                mgr.addVan(cap, plate, vtype);
                pause();
                break;
            }

            case 3: {
                mgr.viewAllVehicles();
                int  vid      = getInt("  Vehicle ID to edit     : ");
                int  newCap   = getInt("  New capacity (0=skip)  : ");
                auto newPlate = getStr("  New plate (blank=skip) : ");
                mgr.editVehicle(vid, newCap, newPlate);
                pause();
                break;
            }

            case 4: {
                mgr.viewAllVehicles();
                mgr.removeVehicle(getInt("  Vehicle ID to remove: "));
                pause();
                break;
            }

            case 5:
                mgr.viewAllVehicles();
                pause();
                break;

            case 6: {
                auto   start = getStr("  Start point : ");
                auto   end   = getStr("  End point   : ");
                double dist  = 0;
                std::cout << "  Distance (km)        : ";
                std::cin >> dist; clearInput();
                double fee = 0;
                std::cout << "  Monthly fee (0=auto) : ";
                std::cin >> fee; clearInput();
                mgr.addRoute(start, end, dist, fee);
                pause();
                break;
            }

            case 7: {
                mgr.viewAllRoutes();
                int rid = getInt("  Route ID   : ");
                mgr.viewAllVehicles();
                int vid = getInt("  Vehicle ID : ");
                mgr.assignVehicleToRoute(rid, vid);
                pause();
                break;
            }

            case 8:
                mgr.viewAllRoutes();
                pause();
                break;

            case 9:
                mgr.viewPendingApplications();
                pause();
                break;

            case 10: {
                mgr.viewPendingApplications();
                mgr.approveApplication(getInt("  Pass ID to approve: "));
                pause();
                break;
            }

            case 11: {
                mgr.viewPendingApplications();
                mgr.rejectApplication(getInt("  Pass ID to reject: "));
                pause();
                break;
            }

            case 12:
                mgr.generateMonthlyBills();
                pause();
                break;

            case 13:
                mgr.checkOverdueBills();
                pause();
                break;

            case 14:
                mgr.generateAllReports();
                pause();
                break;

            case 15:
                mgr.saveData();
                pause();
                break;

            case 0:
                mgr.logout();
                break;

            default:
                std::cout << "  [!] Invalid option.\n";
        }
    } while (choice != 0);
}
int main() {// MAIN FUNCTION
    std::cout << "\n  +============================================+\n";
    std::cout <<   "  |   University Transport Management System   |\n";
    std::cout <<   "  |   OOP Project  —  C++                      |\n";
    std::cout <<   "  +============================================+\n";

    TransportManager mgr;
    mgr.loadData();
    if (mgr.login("admin", "admin123") == nullptr) { // CREATE DEFAULT ADMIN ON VERY FIRST RUN
        std::cout << "  [Setup] Creating default admin account...\n";
        mgr.registerUser("admin", "admin123", "admin", "Transport Office");
    } else {
        mgr.logout();
    }

    int choice;
    do {
        showHeader("MAIN MENU");
        std::cout << "  1. Register New User\n"
                  << "  2. Login\n"
                  << "  0. Exit\n";
        choice = getInt("\n  Enter choice: ");

        switch (choice) {

            case 1: {
                auto name = getStr("  Username                  : ");
                auto pwd  = getStr("  Password                  : ");
                int  ri   = getInt("  Role (1=Student  2=Admin) : ");
                std::string role  = (ri == 2) ? "admin" : "student";
                std::string extra = "";
                if (role == "admin")
                    extra = getStr("  Department: ");
                mgr.registerUser(name, pwd, role, extra);
                pause();
                break;
            }

            case 2: {
                auto  name = getStr("  Username : ");
                auto  pwd  = getStr("  Password : ");
                User* u    = mgr.login(name, pwd);
                if (u) {
                    if (u->getRole() == "student") //OOP: POLYMORPHISM - DYNAMIC_CAST CHECKS ACTUAL RUNTIME TYPE
                        studentMenu(mgr, dynamic_cast<Student*>(u));
                    else
                        adminMenu(mgr);
                } else {
                    pause();
                }
                break;
            }

            case 0:
                std::cout << "\n  Saving before exit...\n";
                mgr.saveData();
                std::cout << "  Goodbye!\n\n";
                break;

            default:
                std::cout << "  [!] Invalid option.\n";
        }
    } while (choice != 0);

    return 0;
}
